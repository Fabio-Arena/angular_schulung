import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<div class="imgdiv"><img  class="img1" src="assets/{{image_path}}"></div>
  <button (click)="clickFunction()" type="button" gradient="peach" rounded="true" mdbWavesEffect>BILD WECHSEL</button>
  <br>
  <br>
  <input placeholder="Enter message" name="msg"/>
  <button (click)="clickFunction2()" type="button" gradient="peach" rounded="true" mdbWavesEffect>SUBMITTIEREN</button>
  <br>
  <br>
  <table>
  <tr>
    <th>Utensilien</th>
  </tr>
  <tr>
    <td>Küchenmesser</td>
  </tr>
  <tr>
    <td>Gurkenschäler</td>
  </tr>
</table>
  `

})

export class AppComponent {
  title = 'schulung';
  content: string  = "Hallo Welt!";
  image_path: string = "landscape1.jpg"

  clickFunction() {
    if (this.image_path == "landscape1.jpg"){
      this.image_path = "landscape2.jpeg"
    }
    else{
      this.image_path = "landscape1.jpg"
    }
  }

  clickFunction2(){
    alert("test")
  }
}

